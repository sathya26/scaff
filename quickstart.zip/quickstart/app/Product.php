<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Product.
 *
 * @author  The scaffold-interface created at 2016-12-02 11:34:15am
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Product extends Model
{
	
	use SoftDeletes;

	protected $dates = ['deleted_at'];
    
	
    protected $table = 'products';

	
}
