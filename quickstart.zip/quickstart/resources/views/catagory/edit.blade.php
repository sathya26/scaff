@extends('scaffold-interface.layouts.defaultMaterialize')
@section('title','Edit')
@section('content')

<div class = 'container'>
    <h1>
        Edit catagory
    </h1>
    <form method = 'get' action = '{!!url("catagory")!!}'>
        <button class = 'btn blue'>catagory Index</button>
    </form>
    <br>
    <form method = 'POST' action = '{!! url("catagory")!!}/{!!$catagory->
        id!!}/update'> 
        <input type = 'hidden' name = '_token' value = '{{Session::token()}}'>
        <div class="input-field col s6">
            <input id="name" name = "name" type="text" class="validate" value="{!!$catagory->
            name!!}"> 
            <label for="name">name</label>
        </div>
        <div class="input-field col s6">
            <input id="Created_by" name = "Created_by" type="text" class="validate" value="{!!$catagory->
            Created_by!!}"> 
            <label for="Created_by">Created_by</label>
        </div>
        <div class="input-field col s6">
            <input id="update_by" name = "update_by" type="text" class="validate" value="{!!$catagory->
            update_by!!}"> 
            <label for="update_by">update_by</label>
        </div>
        <div class="input-field col s6">
            <input id="parant_id" name = "parant_id" type="text" class="validate" value="{!!$catagory->
            parant_id!!}"> 
            <label for="parant_id">parant_id</label>
        </div>
        <button class = 'btn red' type ='submit'>Update</button>
    </form>
</div>
@endsection