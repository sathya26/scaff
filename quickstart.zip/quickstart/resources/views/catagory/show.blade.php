@extends('scaffold-interface.layouts.defaultMaterialize')
@section('title','Show')
@section('content')

<div class = 'container'>
    <h1>
        Show catagory
    </h1>
    <form method = 'get' action = '{!!url("catagory")!!}'>
        <button class = 'btn blue'>catagory Index</button>
    </form>
    <table class = 'highlight bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>name : </i></b>
                </td>
                <td>{!!$catagory->name!!}</td>
            </tr>
            <tr>
                <td>
                    <b><i>Created_by : </i></b>
                </td>
                <td>{!!$catagory->Created_by!!}</td>
            </tr>
            <tr>
                <td>
                    <b><i>update_by : </i></b>
                </td>
                <td>{!!$catagory->update_by!!}</td>
            </tr>
            <tr>
                <td>
                    <b><i>parant_id : </i></b>
                </td>
                <td>{!!$catagory->parant_id!!}</td>
            </tr>
        </tbody>
    </table>
</div>
@endsection