<?php $__env->startSection('title','Show'); ?>
<?php $__env->startSection('content'); ?>

<div class = 'container'>
    <h1>
        Show product
    </h1>
    <form method = 'get' action = '<?php echo url("product"); ?>'>
        <button class = 'btn blue'>product Index</button>
    </form>
    <table class = 'highlight bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>name : </i></b>
                </td>
                <td><?php echo $product->name; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>price : </i></b>
                </td>
                <td><?php echo $product->price; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>slug : </i></b>
                </td>
                <td><?php echo $product->slug; ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.defaultMaterialize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>