<div class="modal-footer">
    <a href = "#" class="closeModal modal-action modal-close waves-effect waves-green btn-flat">close</a>
    <a href = "#" class="waves-effect waves-green btn-flat remove" data-link = "<?php echo e($link); ?>"><?php echo e($action); ?></a>
</div>
</div>
