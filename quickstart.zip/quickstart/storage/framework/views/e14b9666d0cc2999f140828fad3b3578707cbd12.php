<div class="row">
    <div class="file-field input-field col s12">
        <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <select id = "<?php echo e($name); ?>" name = "<?php echo e($name); ?>">
            <option value="" disabled selected>Choose your option</option>
            <?php if($value): ?>
            <?php foreach($value as $v): ?>
            <option value = '<?php echo e($v); ?>'><?php echo e($v); ?></option>
            <?php endforeach; ?>
            <?php endif; ?>
        </select>
    </div>
</div>
