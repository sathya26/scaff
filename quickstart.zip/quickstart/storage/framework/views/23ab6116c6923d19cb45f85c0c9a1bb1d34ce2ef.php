@extends('scaffold-interface.layouts.defaultMaterialize')
@section('title','Edit')
@section('content')
<div class = 'container'>
    <h1>Edit <?php echo e($parser->singular()); ?></h1>
    <form method = 'get' action = '{!!url("<?php echo e($parser->singular()); ?>")!!}'>
        <button class = 'btn blue'><?php echo e($parser->singular()); ?> Index</button>
    </form>
    <br>
    <form method = 'POST' action = '{!! url("<?php echo e($parser->singular()); ?>")!!}/{!!$<?php echo e($parser->singular()); ?>->id!!}/update'>
        <input type = 'hidden' name = '_token' value = '{{Session::token()}}'>
        <?php foreach($dataSystem->dataScaffold('v') as $value): ?>
        <div class="input-field col s6">
            <input id="<?php echo e($value); ?>" name = "<?php echo e($value); ?>" type="text" class="validate" value="{!!$<?php echo e($parser->singular()); ?>-><?php echo e($value); ?>!!}">
            <label for="<?php echo e($value); ?>"><?php echo e($value); ?></label>
        </div>
        <?php endforeach; ?>
        <?php foreach($dataSystem->getForeignKeys() as $key): ?>
        <div class="input-field col s12">
            <select name = '<?php echo e(lcfirst(str_singular($key))); ?>_id'>
                @foreach($<?php echo e(str_plural($key)); ?> as $key => $value)
                <option value="{{$key}}">{{$value}}</option>
                @endforeach
            </select>
            <label><?php echo e($key); ?> Select</label>
        </div>
        <?php endforeach; ?>
        <button class = 'btn red' type ='submit'>Update</button>
    </form>
</div>
@endsection
