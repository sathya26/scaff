<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class = 'container'>
    <h1>
        catagory Index
    </h1>
    <div class="row">
        <form class = 'col s3' method = 'get' action = '<?php echo url("catagory"); ?>/create'>
            <button class = 'btn red' type = 'submit'>Create New catagory</button>
        </form>
    </div>
    <table>
        <thead>
            <th>name</th>
            <th>Created_by</th>
            <th>update_by</th>
            <th>parant_id</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php foreach($catagories as $catagory): ?> 
            <tr>
                <td><?php echo $catagory->name; ?></td>
                <td><?php echo $catagory->Created_by; ?></td>
                <td><?php echo $catagory->update_by; ?></td>
                <td><?php echo $catagory->parant_id; ?></td>
                <td>
                    <div class = 'row'>
                        <a href = '#modal1' class = 'delete btn-floating modal-trigger red' data-link = "/catagory/<?php echo $catagory->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                        <a href = '#' class = 'viewEdit btn-floating blue' data-link = '/catagory/<?php echo $catagory->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                        <a href = '#' class = 'viewShow btn-floating orange' data-link = '/catagory/<?php echo $catagory->id; ?>'><i class = 'material-icons'>info</i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?> 
        </tbody>
    </table>
    <?php echo $catagories->render(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.defaultMaterialize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>