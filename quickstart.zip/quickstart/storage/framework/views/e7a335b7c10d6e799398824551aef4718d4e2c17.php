@extends('scaffold-interface.layouts.defaultMaterialize')
@section('title','Index')
@section('content')
<div class = 'container'>
    <h1><?php echo e($parser->singular()); ?> Index</h1>
    <div class="row">
        <form class = 'col s3' method = 'get' action = '{!!url("<?php echo e($parser->singular()); ?>")!!}/create'>
            <button class = 'btn red' type = 'submit'>Create New <?php echo e($parser->singular()); ?></button>
        </form>
        <?php if($dataSystem->getRelationAttributes() != null): ?>
        <ul id="dropdown" class="dropdown-content">
            <?php foreach($dataSystem->getRelationAttributes() as $key => $value): ?>
            <li><a href="<?php echo e(URL::to('/')); ?>/<?php echo e(lcfirst(str_singular($key))); ?>"><?php echo e(ucfirst(str_singular($key))); ?></a></li>
            <?php endforeach; ?>
        </ul>
        <a class="col s3 btn dropdown-button #1e88e5 blue darken-1" href="#!" data-activates="dropdown">Associate<i class="mdi-navigation-arrow-drop-down right"></i></a>
        <?php endif; ?>
    </div>
    <table>
        <thead>
            <?php foreach($dataSystem->dataScaffold('v') as $value): ?>
            <th><?php echo e($value); ?></th>
            <?php endforeach; ?>
            <?php if($dataSystem->getRelationAttributes() != null): ?>
            <?php foreach($dataSystem->getRelationAttributes() as $key => $value): ?>
            <?php foreach($value as $key1 => $value1): ?>
            <th><?php echo e($value1); ?></th>
            <?php endforeach; ?>
            <?php endforeach; ?>
            <?php endif; ?>
            <th>actions</th>
        </thead>
        <tbody>
            @foreach($<?php echo e($parser->plural()); ?> as $<?php echo e(lcfirst($parser->singular())); ?>)
            <tr>
                <?php foreach($dataSystem->dataScaffold('v') as $value): ?>
                <td>{!!$<?php echo e(lcfirst($parser->singular())); ?>-><?php echo e($value); ?>!!}</td>
                <?php endforeach; ?>
                <?php if($dataSystem->getRelationAttributes() != null): ?>
                <?php foreach($dataSystem->getRelationAttributes() as $key=>$value): ?>
                <?php foreach($value as $key1 => $value1): ?>
                <td>{!!$<?php echo e($parser->singular()); ?>-><?php echo e(str_singular($key)); ?>-><?php echo e($value1); ?>!!}</td>
                <?php endforeach; ?>
                <?php endforeach; ?>
                <?php endif; ?>
                <td>
                    <div class = 'row'>
                        <a href = '#modal1' class = 'delete btn-floating modal-trigger red' data-link = "/<?php echo e($parser->singular()); ?>/{!!$<?php echo e($parser->singular()); ?>->id!!}/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                        <a href = '#' class = 'viewEdit btn-floating blue' data-link = '/<?php echo e($parser->singular()); ?>/{!!$<?php echo e($parser->singular()); ?>->id!!}/edit'><i class = 'material-icons'>edit</i></a>
                        <a href = '#' class = 'viewShow btn-floating orange' data-link = '/<?php echo e($parser->singular()); ?>/{!!$<?php echo e($parser->singular()); ?>->id!!}'><i class = 'material-icons'>info</i></a>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {!! $<?php echo e($parser->plural()); ?>->render() !!}
</div>
@endsection
