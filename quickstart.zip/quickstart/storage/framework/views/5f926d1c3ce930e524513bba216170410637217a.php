<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class = 'container'>
    <h1>
        product Index
    </h1>
    <div class="row">
        <form class = 'col s3' method = 'get' action = '<?php echo url("product"); ?>/create'>
            <button class = 'btn red' type = 'submit'>Create New product</button>
        </form>
    </div>
    <table>
        <thead>
            <th>name</th>
            <th>price</th>
            <th>slug</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php foreach($products as $product): ?> 
            <tr>
                <td><?php echo $product->name; ?></td>
                <td><?php echo $product->price; ?></td>
                <td><?php echo $product->slug; ?></td>
                <td>
                    <div class = 'row'>
                        <a href = '#modal1' class = 'delete btn-floating modal-trigger red' data-link = "/product/<?php echo $product->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                        <a href = '#' class = 'viewEdit btn-floating blue' data-link = '/product/<?php echo $product->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                        <a href = '#' class = 'viewShow btn-floating orange' data-link = '/product/<?php echo $product->id; ?>'><i class = 'material-icons'>info</i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?> 
        </tbody>
    </table>
    <?php echo $products->render(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.defaultMaterialize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>