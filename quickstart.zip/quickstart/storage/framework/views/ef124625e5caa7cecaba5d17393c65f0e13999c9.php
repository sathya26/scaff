<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>

<div class = 'container'>
    <h1>
        Create product
    </h1>
    <form method = 'get' action = '<?php echo url("product"); ?>'>
        <button class = 'btn blue'>product Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("product"); ?>'>
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="input-field col s6">
            <input id="name" name = "name" type="text" class="validate">
            <label for="name">name</label>
        </div>
        <div class="input-field col s6">
            <input id="price" name = "price" type="text" class="validate">
            <label for="price">price</label>
        </div>
        <div class="input-field col s6">
            <input id="slug" name = "slug" type="text" class="validate">
            <label for="slug">slug</label>
        </div>
        <button class = 'btn red' type ='submit'>Create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.defaultMaterialize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>