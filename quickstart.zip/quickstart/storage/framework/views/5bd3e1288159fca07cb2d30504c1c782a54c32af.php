<?php $__env->startSection('title','Show'); ?>
<?php $__env->startSection('content'); ?>

<div class = 'container'>
    <h1>
        Show catagory
    </h1>
    <form method = 'get' action = '<?php echo url("catagory"); ?>'>
        <button class = 'btn blue'>catagory Index</button>
    </form>
    <table class = 'highlight bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>name : </i></b>
                </td>
                <td><?php echo $catagory->name; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>Created_by : </i></b>
                </td>
                <td><?php echo $catagory->Created_by; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>update_by : </i></b>
                </td>
                <td><?php echo $catagory->update_by; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>parant_id : </i></b>
                </td>
                <td><?php echo $catagory->parant_id; ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.defaultMaterialize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>