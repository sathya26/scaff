@extends('scaffold-interface.layouts.defaultMaterialize')
@section('title','Show')
@section('content')
<div class = 'container'>
    <h1>Show <?php echo e($parser->singular()); ?></h1>
    <form method = 'get' action = '{!!url("<?php echo e($parser->singular()); ?>")!!}'>
        <button class = 'btn blue'><?php echo e($parser->singular()); ?> Index</button>
    </form>
    <table class = 'highlight bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <?php foreach($dataSystem->dataScaffold('v') as $value): ?>
            <tr>
                <td>
                    <b><i><?php echo e($value); ?> : </i></b>
                </td>
                <td>{!!$<?php echo e($parser->singular()); ?>-><?php echo e($value); ?>!!}</td>
            </tr>
            <?php endforeach; ?>
            <?php if($dataSystem->getRelationAttributes() != null): ?>
            <?php foreach($dataSystem->getRelationAttributes() as $key=>$value): ?>
            <?php foreach($value as $key1 => $value1): ?>
            <tr>
                <td>
                    <b><i><?php echo e($value1); ?> : </i><b>
                </td>
                <td>{!!$<?php echo e($parser->singular()); ?>-><?php echo e(str_singular($key)); ?>-><?php echo e($value1); ?>!!}</td>
            </tr>
            <?php endforeach; ?>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
@endsection
