<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

/**
 * Class Catagories.
 *
 * @author  The scaffold-interface created at 2016-12-02 11:56:26am
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Catagories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return  void
     */
    public function up()
    {
        Schema::create('catagories',function (Blueprint $table){

        $table->increments('id');
        
        $table->String('name');
        
        $table->integer('Created_by');
        
        $table->integer('update_by');
        
        $table->integer('parant_id');
        
        /**
         * Foreignkeys section
         */
        
        
        $table->timestamps();
        
        
        $table->softDeletes();
        
        // type your addition here

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return  void
     */
    public function down()
    {
        Schema::drop('catagories');
    }
}
